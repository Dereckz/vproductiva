<?php include 'consulta.php';?>
<!DOCTYPE html>
<!-- saved from url=(0091)https://website529400.nicepage.io/es/1234.html?version=56a80d83-e130-4c50-b76e-7bfc4c0ea516 -->
<html style="font-size: 16px;" lang="en" class="u-responsive-xl"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="keywords" content="​Hello!">
    <meta name="description" content="">
    <title>1234</title>
    <link rel="stylesheet" href="./nicepage.css" media="screen" class="u-static-style">
    <link rel="stylesheet" href="./nicepage(1).css" media="screen">
    <script class="u-script" type="text/javascript" src="./jquery-1.9.1.min.js.descarga" defer=""></script>
    <script class="u-script" type="text/javascript" src="./nicepage.js.descarga" defer=""></script>
    <meta name="generator" content="Nicepage 4.18.8, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="./css">
    <style class="u-style"> .u-section-2 {
  background-image: none;
}
.u-section-2 .u-sheet-1 {
  min-height: 1108px;
}
.u-section-2 .u-text-1 {
  text-transform: uppercase;
  font-size: 1.2rem;
  --animation-custom_in-scale: 1;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: -300px;
  /*margin: 90px 405px 0 0;*/
  color: blue;
  font-family: Open Sans;
}
.u-section-2 .u-text-2 {
  font-size: 3rem;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: -300px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 0deg;
  --animation-custom_in-scale: 1;
  font-weight: 500;
  /*margin: 42px 335px 0 0;*/
  color: purple;
}
.u-section-2 .u-text-3 {
  line-height: 2;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 300px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 0deg;
  --animation-custom_in-scale: 1;
  /*margin: 20px 327px 0 0;*/
}
.u-section-2 .u-text-4 {
  --animation-custom_in-scale: 1;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 300px;
  margin: 35px 503px 0 0;
}
.u-section-2 .u-btn-1 {
  margin-left: auto;
  padding: 0;
}
.u-section-2 .u-list-1 {
  margin-top: 52px;
  margin-bottom: 0;
}
.u-section-2 .u-repeater-1 {
  grid-template-columns: repeat(4, calc(25% - 22.5px));
  min-height: 273px;
  grid-gap: 30px;
}
.u-section-2 .u-list-item-1 {
  background-image: none;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 300px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 0deg;
  --animation-custom_in-scale: 1;
  box-shadow: 5px 5px 29px 0 rgba(0,0,0,0.15);
}
.u-section-2 .u-container-layout-1 {
  padding: 50px 30px 30px;
}
.u-section-2 .u-icon-1 {
  height: 59px;
  width: 59px;
  background-image: none;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 0px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 180deg;
  --animation-custom_in-scale: 1;
  margin: 0 auto 0 0;
  padding: 0;
}
.u-section-2 .u-text-5 {
  font-size: 1.5rem;
  font-weight: 400;
  margin: 31px 0 0;
}
.u-section-2 .u-btn-2 {
  font-size: 0.875rem;
  background-image: none;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-weight: 600;
  margin: 20px 0 0;
  padding: 0;
}
.u-section-2 .u-list-item-2 {
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 300px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 0deg;
  --animation-custom_in-scale: 1;
  box-shadow: 5px 5px 29px 0 rgba(0,0,0,0.15);
}
.u-section-2 .u-container-layout-2 {
  padding: 50px 30px 30px;
}
.u-section-2 .u-icon-2 {
  height: 59px;
  width: 59px;
  background-image: none;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 0px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 180deg;
  --animation-custom_in-scale: 1;
  margin: 0 auto 0 0;
  padding: 0;
}
.u-section-2 .u-text-6 {
  font-size: 1.5rem;
  font-weight: 400;
  margin: 31px 0 0;
}
.u-section-2 .u-btn-3 {
  font-size: 0.875rem;
  background-image: none;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-weight: 600;
  margin: 20px 0 0;
  padding: 0;
}
.u-section-2 .u-list-item-3 {
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 300px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 0deg;
  --animation-custom_in-scale: 1;
  box-shadow: 5px 5px 29px 0 rgba(0,0,0,0.15);
}
.u-section-2 .u-container-layout-3 {
  padding: 50px 30px 30px;
}
.u-section-2 .u-icon-3 {
  height: 59px;
  width: 59px;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 0px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 180deg;
  --animation-custom_in-scale: 1;
  margin: 0 auto 0 0;
  padding: 0;
}
.u-section-2 .u-text-7 {
  font-size: 1.5rem;
  font-weight: 400;
  margin: 31px 0 0;
}
.u-section-2 .u-btn-4 {
  font-size: 0.875rem;
  background-image: none;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-weight: 600;
  margin: 20px 0 0;
  padding: 0;
}
.u-section-2 .u-list-item-4 {
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 300px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 0deg;
  --animation-custom_in-scale: 1;
  box-shadow: 5px 5px 29px 0px rgba(0,0,0,0.15);
}
.u-section-2 .u-container-layout-4 {
  padding: 50px 30px 30px;
}
.u-section-2 .u-icon-4 {
  height: 59px;
  width: 59px;
  background-image: none;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 0px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 180deg;
  --animation-custom_in-scale: 1;
  margin: 0 auto 0 0;
  padding: 0;
}
.u-section-2 .u-text-8 {
  font-size: 1.5rem;
  font-weight: 400;
  margin: 31px 0 0;
}
.u-section-2 .u-btn-5 {
  font-size: 0.875rem;
  background-image: none;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-weight: 600;
  margin: 20px 0 0;
  padding: 0;
}
.u-section-2 .u-group-1 {
  min-height: 257px;
  margin-top: 52px;
  margin-bottom: 60px;
  height: auto;
  --animation-custom_in-translate_x: 0px;
  --animation-custom_in-translate_y: 300px;
  --animation-custom_in-opacity: 0;
  --animation-custom_in-rotate: 0deg;
  --animation-custom_in-scale: 1;
}
.u-section-2 .u-container-layout-5 {
  padding: 30px;
}
.u-section-2 .u-text-9 {
  font-size: 3rem;
  margin: 0 auto 0 0;
}
.u-section-2 .u-btn-6 {
  border-style: solid;
  text-transform: uppercase;
  font-weight: 700;
  letter-spacing: 2px;
  font-size: 0.875rem;
  align-self: center;
  text-align: center;
  margin: 15px auto 0 0;
  padding: 14px 46px 16px 44px;
}
@media (max-width: 1199px) {
  .u-section-2 .u-text-1 {
    margin-right: 205px;
  }
  .u-section-2 .u-text-2 {
    margin-right: 135px;
  }
  .u-section-2 .u-text-3 {
    margin-right: 127px;
  }
  .u-section-2 .u-text-4 {
    margin-right: 303px;
  }
  .u-section-2 .u-repeater-1 {
    min-height: 221px;
  }
  .u-section-2 .u-container-layout-1 {
    padding-top: 40px;
    padding-left: 20px;
    padding-right: 20px;
  }
  .u-section-2 .u-group-1 {
    height: auto;
  }
}
@media (max-width: 991px) {
  .u-section-2 .u-sheet-1 {
    min-height: 1439px;
  }
  .u-section-2 .u-text-1 {
    margin-top: 60px;
    margin-right: 0;
  }
  .u-section-2 .u-text-2 {
    margin-right: 0;
  }
  .u-section-2 .u-text-3 {
    margin-right: 0;
  }
  .u-section-2 .u-text-4 {
    margin-right: 83px;
  }
  .u-section-2 .u-repeater-1 {
    grid-template-columns: repeat(2, calc(50% - 15px));
    min-height: 557px;
  }
  .u-section-2 .u-container-layout-1 {
    padding-top: 30px;
  }
  .u-section-2 .u-container-layout-2 {
    padding-top: 30px;
  }
  .u-section-2 .u-container-layout-3 {
    padding-top: 30px;
  }
  .u-section-2 .u-container-layout-4 {
    padding-top: 30px;
  }
  .u-section-2 .u-group-1 {
    min-height: 302px;
  }
}
@media (max-width: 767px) {
  .u-section-2 .u-text-4 {
    margin-right: 0;
  }
  .u-section-2 .u-repeater-1 {
    grid-auto-columns: calc(50% - 15px);
  }
  .u-section-2 .u-container-layout-2 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-section-2 .u-container-layout-3 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-section-2 .u-container-layout-4 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-section-2 .u-group-1 {
    min-height: 302px;
  }
  .u-section-2 .u-container-layout-5 {
    padding-left: 20px;
    padding-right: 20px;
  }
  .u-section-2 .u-text-9 {
    font-size: 2.25rem;
  }
  .u-section-2 .u-btn-6 {
    margin-top: 20px;
  }
}
@media (max-width: 575px) {
  .u-section-2 .u-text-2 {
    font-size: 2.25rem;
  }
  .u-section-2 .u-repeater-1 {
    grid-template-columns: 100%;
    grid-auto-columns: calc(100% - 0px);
  }
  .u-section-2 .u-container-layout-2 {
    padding-left: 20px;
    padding-right: 20px;
  }
  .u-section-2 .u-container-layout-3 {
    padding-left: 20px;
    padding-right: 20px;
  }
  .u-section-2 .u-container-layout-4 {
    padding-left: 20px;
    padding-right: 20px;
  }
  .u-section-2 .u-text-9 {
    font-size: 1.875rem;
  }
}</style>

    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"url": "https://website529400.nicepage.io/1234.html"
}</script>
    <meta name="theme-color" content="#0066ff">
    <meta property="og:title" content="1234">
    <meta property="og:type" content="website">
    <link rel="canonical" href="https://website529400.nicepage.io/1234.html">
    <link rel="stylesheet" href="estiloencabezado.css">

</head>
  <body class="u-body u-xl-mode" data-lang="en">
  <header id="encabezado">
    	<!--<div id="logotipo">
    	<img src="img/logovproductiva2.png" id="logo"> 
    	</div>-->
    	<!--<h1 id="tituloprincipal">Valuacion Productiva</h1>-->
    	<ul id="menu">
      <li class="logo"><img src="img/logovproductiva2.png" id="logo"></li>
      <li class="menus"></li>
    	<li class="menus"><a href="indexalumnos.php">Mi perfil</a></li>
    	<li class="menus"><a href="cursos.php">Catalogo de Cursos</a></li>
      <li class="menus"><a href="../account/login.html">Salir</a></li>
    	</ul>
  </header>

    <section class="u-align-left u-clearfix u-grey-5 u-section-2" id="carousel_0852">
      <div class="u-clearfix u-sheet u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-sheet-1">
        <h4 class="u-text u-text-1 animated customAnimationIn-played" data-animation-name="customAnimationIn" data-animation-duration="1500" style="will-change: transform, opacity; animation-duration: 1500ms;">Perfil
        </h4>
        <?=informacion();?>

        <h4 class="u-text u-text-1 animated customAnimationIn-played" data-animation-name="customAnimationIn" data-animation-duration="1500" style="will-change: transform, opacity; animation-duration: 1500ms;">Mis Cursos</h4>
        <div class="u-expanded-width u-list u-list-1">
        <div class="u-repeater u-repeater-1">
        <?=miCurso();?>
        </div>
        </div>
        <div class="u-align-left u-container-style u-expanded-width u-group u-palette-1-base u-group-1 animated customAnimationIn-played" data-animation-name="customAnimationIn" data-animation-duration="1750" data-animation-delay="500" style="will-change: transform, opacity; animation-duration: 1750ms;">
          <div class="u-container-layout u-valign-middle u-container-layout-5">
            <h3 class="u-text u-text-default u-text-9"> Si quieres aprender más, consulta nuestro catalogo de cursos he inscribete.</h3>
            <a href="cursos.php" class="u-active-white u-align-center u-border-1 u-border-active-white u-border-hover-white u-border-white u-btn u-button-style u-hover-white u-none u-text-active-palette-1-base u-text-hover-palette-1-base u-btn-6" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">Catálogo de cursos</a>
          </div>
        </div>
      </div>
    </section>


    <section class="u-backlink u-clearfix u-grey-80">
      <a class="u-link" href="https://nicepage.com/website-templates" target="_blank">
        <span>Website Templates</span>
      </a>
      <p class="u-text">
        <span>creado con</span>
      </p>
      <a class="u-link" href="https://nicepage.com/" target="_blank">
        <span>Website Builder Software</span>
      </a>.
    </section>

<style>.u-disable-duration * {transition-duration: 0s !important;}</style></body></html>