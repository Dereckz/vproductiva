# Dashboard (Step by step learn Html + Css best practices)

Build Dashboard using Html and Css only

![alt text](./img/dashboard-1.png)

![alt text](./img/dashboard-2.png)

by:

[Dylut2000 Twitter](https://twitter.com/dylut2000)

[Dylut2000 Github](https://github.com/dylut2000)
